# dev-fonts
This repository for to get free fonts for the development. At the moment I have uploaded font FIRA and Operator Mono. Feel free to share this repository with others. If you like it then give a star to this repository. :)
